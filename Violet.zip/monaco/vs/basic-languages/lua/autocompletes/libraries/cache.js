define(["require", "exports"], function (require, exports) {
	Object.defineProperty(exports, "__esModule", { value: true });

	exports.autocompletes = {

		Function: {

			/**
			 * Roblox
			 */

			'invalidate(number)': {
				insertText: 'invalidate(${1:number})',
				documentation: {
					value: [
						'```lua\nfunction invalidate(number)\n```',
					].join('\n')
				},
			},

			'iscached(number)': {
				insertText: 'iscached(${1:number})',
				documentation: {
					value: [
						'```lua', 'function iscached(number)', '```',
					].join('\n')
				},
			},

			'replace(number, number)': {
				insertText: 'replace(${1:number}, ${2:number})',
				documentation: {
					value: [
						'```lua', 'function replace(number, number)', '```',
					].join('\n')
				},
			},
		},
	};
});