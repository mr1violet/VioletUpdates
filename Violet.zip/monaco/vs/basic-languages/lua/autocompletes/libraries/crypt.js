define(["require", "exports"], function (require, exports) {
	Object.defineProperty(exports, "__esModule", { value: true });

	exports.autocompletes = {

		Function: {

			/**
			 * Roblox
			 */

			'base64decode(data)': {
				insertText: 'base64decode(${1:data})',
				documentation: {
					value: [
						'```lua\nfunction base64decode(data)\n```',
					].join('\n')
				},
			},

			'base64encode(data)': {
				insertText: 'base64encode(${1:data})',
				documentation: {
					value: [
						'```lua', 'function base64encode(data)', '```',
					].join('\n')
				},
			},

			'decrypt(data, key, iv, String)': {
				insertText: 'decrypt(${1:data}, ${2:key}, ${3:iv}, ${4:String})',
				documentation: {
					value: [
						'```lua', 'function decrypt(data, key, iv, String)', '```',
					].join('\n')
				},
			},

			'encrypt(data, key, iv, String)': {
				insertText: 'encrypt(${1:data}, ${2:key}, ${3:iv}, ${4:String})',
				documentation: {
					value: [
						'```lua', 'function encrypt(data, key, iv, String)', '```',
					].join('\n')
				},
			},

			'encrypt(data, key, iv, String)': {
				insertText: 'encrypt(${1:data}, ${2:key}, ${3:iv}, ${4:String})',
				documentation: {
					value: [
						'```lua', 'function encrypt(data, key, iv, String)', '```',
					].join('\n')
				},
			},

			'derive(data, length)': {
				insertText: 'encrypt(${1:data}, ${2:length})',
				documentation: {
					value: [
						'```lua', 'function encrypt(data, length)', '```',
					].join('\n')
				},
			},

			'generatebytes(size)': {
				insertText: 'generatebytes(${1:size})',
				documentation: {
					value: [
						'```lua', 'function generatebytes(size)', '```',
					].join('\n')
				},
			},

			'generatekey()': {
				insertText: 'generatekey()',
				documentation: {
					value: [
						'```lua', 'function generatekey()', '```',
					].join('\n')
				},
			},

			'hash()': {
				insertText: 'hash()',
				documentation: {
					value: [
						'```lua', 'function hash()', '```',
					].join('\n')
				},
			},

			'random(size)': {
				insertText: 'random(${1:size})',
				documentation: {
					value: [
						'```lua', 'function random(size)', '```',
					].join('\n')
				},
			},
		},
	};
});